import MainRoute from './routes';
import './App.css';

function App() {
  return (
    <div className="App">
      <MainRoute />
    </div>
  );
}

export default App;
